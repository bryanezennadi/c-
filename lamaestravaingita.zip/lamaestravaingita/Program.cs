﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lamaestravaingita
{
    class Program
    {
        static void Main(string[] args)
        {
            int totbambini;
            //inserimento dei bambino all'interno della classe
            Console.WriteLine("quanti bambini ci sono in classe?");
            totbambini = Convert.ToInt32(Console.ReadLine());
            string[] classe;
            string nome2;
            int contabimbi = 0;
            bool finiti = false;
            classe= new string[totbambini];
            for (int i=0; i<classe.Length; i ++)
            {
                Console.WriteLine("inserisci il cognome del bambino");
                classe[i] = Console.ReadLine();

            }
            //visualizzazzione del registro di classe
            for (int i=0; i<classe.Length; i++)
            {
                Console.WriteLine("{1}                     {0}",classe[i], i+1);
                
            }
            
            do
            {
                Console.Clear();
                //si va in gita
               
                Console.WriteLine("chi sale nel pulmann?");
                nome2 = Console.ReadLine();
                for (int i = 0; i < classe.Length; i++)
                {
                    if (classe[i] == nome2)
                    {
                        Console.WriteLine("il bambino è salito sul pulman");
                        contabimbi++;
                    }
                    else
                    {
                        Console.WriteLine("mancano dei bambini");

                    }
                    

                }
                if (contabimbi == classe.Length)
                {
                    finiti = true;
                }

            } while (finiti = false);
            Console.ReadKey();
        }
    }
}
